# V14 - «اعملي برنامجي» Weekly Program Engine

## Goal
Transform a student's real weekly constraints into a practical study program and a visually attractive, printable PDF.

## Inputs
- Student name and target week.
- Enabled subjects.
- Requested study sessions per subject.
- Student-defined priority per subject.
- Available study days.
- Preferred daily study window.
- Session length and break length.
- Maximum study sessions per day.
- Fixed activities: school, tutoring, sports, work, family activities, etc.
- Optional use of Muwajjeh performance/mastery data.

## Scheduling behavior
1. Fixed activities are blocked first.
2. Study sessions are placed only on selected available days and inside the student's preferred study window.
3. Sessions never overlap fixed activities or other study sessions.
4. The engine spreads load across days and penalizes repeating the same subject on the same day when another day is available.
5. User priority always matters. If adaptive priority is enabled, weak mastery, low exam performance, and recorded mistakes add a secondary priority boost.
6. The requested number of sessions is never silently changed.
7. If all sessions cannot fit, the app reports the exact shortage and asks the student to add time/days or lower requested sessions.

## PDF output
Two-page A4 landscape PDF:
- Student name.
- Week date range.
- Personalized motivational phrase.
- Attractive color-coded weekly overview.
- Study-session times by day.
- Subject color legend.
- Detailed table with fixed activities and study sessions.
- Subject session goals and completion counts.
- Muwajjeh study tips and scheduling warnings.

## Arabic PDF typography
The Flutter implementation uses the `printing` package's Google Fonts integration with Noto Naskh Arabic. This keeps Arabic readable in the generated PDF. The font is retrieved/cached by the printing package at runtime rather than bundled as a proprietary app asset.

## Persistence
The student's planner inputs are saved locally with SharedPreferences and are restored on the next visit.
