# V9 Learning Path Engine

## Goal
Turn V8 mastery signals into a measurable remediation loop rather than a static recommendation.

## Target selection
The active path starts from `nextMasteryTarget`, which selects the weakest measured skill (preferring skills with at least two attempts).

## Stages
1. **Concept review** — student confirms that the concept/rule has been reviewed. If a matching mistake exists, the app surfaces the stored explanation.
2. **Foundation practice** — up to 5 targeted questions, preferring the same skill/lesson and easy/medium difficulty. Passing threshold: 60%.
3. **Checkpoint** — up to 5 targeted questions, preferring medium/hard/advanced difficulty. Passing threshold: 80%.
4. **Decision** — pass advances to the next weakest skill; fail enters remediation and prompts another practice/checkpoint cycle.

## Persistence
`LearningPathRecord` is stored in SharedPreferences under `learning_paths_v1`. Assessment attempts reuse `QuestionAttemptRecord`; no duplicate assessment database is created.

## Content integrity
The curriculum determines taxonomy (subject/unit/lesson/skill). Learning guidance is original app content and stored question explanations; it does not reproduce textbook explanations verbatim.

## Backward compatibility
V8 question attempts, mistakes, exam results, focus sessions, and profile keys are unchanged. V9 adds a new persistence key only.
